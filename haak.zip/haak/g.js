$(document).ready(function() {
    // Inicializar el mapa
    var map = L.map('map').setView([19.4326, -99.1332], 10);

    // Añadir capa de OpenStreetMap
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    // Función para obtener datos de sismos
    function obtenerSismos() {
        $.getJSON('https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson', function(data) {
            data.features.forEach(function(sismo) {
                var magnitud = sismo.properties.mag;
                var alerta = sismo.properties.alert || "Sin alerta";
                var coordenadas = sismo.geometry.coordinates;
                var latLng = [coordenadas[1], coordenadas[0]];

                // Añadir marcadores
                L.circleMarker(latLng, {
                    radius: magnitud * 2, // Tamaño del círculo basado en magnitud
                    color: magnitud >= 5 ? 'red' : 'orange',
                    fillOpacity: 0.5
                }).addTo(map).bindPopup(`Magnitud: ${magnitud}<br>Alerta: ${alerta}`);
            });
        });
    }

    obtenerSismos();
});
