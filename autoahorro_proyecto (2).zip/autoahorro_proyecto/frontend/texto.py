import zipfile
import os

# Definir estructura del proyecto
project_files = {
    "README.md": """
# Simulador de Ahorro e Inversión

## Descripción

Esta aplicación web permite simular la evolución financiera personal a lo largo del tiempo, integrando automatizaciones de ahorro y proyecciones de inversión. A través de una interfaz amigable, el usuario puede ingresar sus gastos diarios, definir reglas de redondeo, establecer aportaciones fijas y extraordinarias, así como planificar inversiones a largo plazo considerando el interés compuesto.

El sistema se compone de:

- **Un backend en FastAPI**, que procesa los datos y aplica las reglas financieras definidas.
- **Un frontend en React**, que presenta formularios interactivos y gráficas dinámicas con los resultados.
- **Integración opcional con Docker**, para desplegar fácilmente tanto el servidor como la interfaz.

Está diseñado para ayudar a las personas a entender el impacto de sus hábitos de consumo, ahorro e inversión en su patrimonio futuro.
""",

    "requirements.txt": "fastapi\nuvicorn\npydantic\n",

    "backend/main.py": """
from fastapi import FastAPI
from pydantic import BaseModel
from typing import List

app = FastAPI()

class Gasto(BaseModel):
    date: str
    amount: float

@app.post("/invertido/")
def calcular_inversion(gastos: List[Gasto]):
    total = 0
    for gasto in gastos:
        redondeado = ((int(gasto.amount / 100) + 1) * 100)
        remanente = redondeado - gasto.amount
        total += remanente
    return {"total_invertido": total}
""",

    "frontend/package.json": """
{
  "name": "simulador-ahorro",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "start": "vite"
  },
  "dependencies": {
    "react": "^18.0.0",
    "react-dom": "^18.0.0",
    "recharts": "^2.1.9"
  },
  "devDependencies": {
    "vite": "^4.0.0"
  }
}
""",

    "frontend/src/App.jsx": """
import React, { useEffect, useState } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

function App() {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8000/invertido/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify([
        { "date": "2023-10-12", "amount": 250 },
        { "date": "2023-02-28", "amount": 375 },
        { "date": "2023-07-01", "amount": 620 },
        { "date": "2023-12-17", "amount": 480 }
      ])
    })
    .then(res => res.json())
    .then(json => setData([{ name: "Invertido", value: json.total_invertido }]));
  }, []);

  return (
    <div className="App">
      <h1>Inversión acumulada</h1>
      <LineChart width={500} height={300} data={data}>
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <CartesianGrid stroke="#eee" strokeDasharray="5 5" />
        <Line type="monotone" dataKey="value" stroke="#8884d8" />
      </LineChart>
    </div>
  );
}

export default App;
"""
}

# Crear zip
zip_path = "/mnt/data/simulador_ahorro.zip"
with zipfile.ZipFile(zip_path, 'w') as zipf:
    for filepath, content in project_files.items():
        temp_path = f"/tmp/{filepath}"
        os.makedirs(os.path.dirname(temp_path), exist_ok=True)
        with open(temp_path, "w", encoding="utf-8") as f:
            f.write(content)
        zipf.write(temp_path, arcname=filepath)

zip_path
