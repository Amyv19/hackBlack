import React, { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

function App() {
  const [data, setData] = useState([]);
  const [total, setTotal] = useState(0);

  const fetchData = async () => {
    const response = await fetch("http://localhost:8000/calculate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        expenses: [
          { date: "2025-01-10", amount: 1519 },
          { date: "2025-05-23", amount: 880 },
          { date: "2025-09-01", amount: 999 }
        ],
        fixed_ranges: [
          { start: "2025-01-01", end: "2025-03-31", fixed: 50 }
        ],
        extra_ranges: [
          { start: "2025-05-01", end: "2025-07-31", extra: 25 }
        ],
        valid_ranges: [
          { start: "2025-01-01", end: "2025-12-31" }
        ]
      })
    });
    const result = await response.json();
    setTotal(result.total);
    setData(result.details);
  };

  return (
    <div className="App" style={{ padding: "2rem" }}>
      <h2>Total Invertido: ${total}</h2>
      <button onClick={fetchData}>Calcular</button>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data}>
          <XAxis dataKey="date" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="invested" fill="#8884d8" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export default App;