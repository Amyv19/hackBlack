from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class Expense(BaseModel):
    date: datetime
    amount: float

class Situation(BaseModel):
    fixed: Optional[float] = None
    extra: Optional[float] = None
    start: datetime
    end: datetime

class InputData(BaseModel):
    expenses: List[Expense]
    situations: List[Situation]

@app.post("/calculate")
def calculate_savings(data: InputData):
    total_saved = 0
    breakdown = []

    for expense in data.expenses:
        rounded = ((int(expense.amount) // 100) + 1) * 100
        saved = rounded - expense.amount
        applied = saved

        for situation in data.situations:
            if situation.start <= expense.date <= situation.end:
                if situation.fixed:
                    applied = situation.fixed
                elif situation.extra:
                    applied += situation.extra

        breakdown.append({
            "date": expense.date,
            "amount": expense.amount,
            "saved": applied
        })
        total_saved += applied

    return {"total_saved": total_saved, "breakdown": breakdown}
