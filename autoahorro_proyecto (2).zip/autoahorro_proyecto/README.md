# Autoahorro Proyecto

## Requisitos

- Node.js y npm
- Python 3.10+
- FastAPI y React

## Backend

```bash
cd backend
uvicorn main:app --reload --port 8000
```

## Frontend

```bash
cd frontend
npm install
npm run dev
```

## Estructura

```
proyecto/
├── backend/
│   └── main.py
├── frontend/
│   ├── src/
│   │   └── App.jsx
│   └── package.json
├── requirements.txt
└── README.md
```